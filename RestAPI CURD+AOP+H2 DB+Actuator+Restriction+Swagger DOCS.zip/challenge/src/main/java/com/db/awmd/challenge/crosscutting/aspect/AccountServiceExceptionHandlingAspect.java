package com.db.awmd.challenge.crosscutting.aspect;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.db.awmd.challenge.exception.AccountNotDeletedException;
import com.db.awmd.challenge.exception.AccountNotFoundException;
import com.db.awmd.challenge.exception.DuplicateAccountIdException;
import com.db.awmd.challenge.exception.NegativeBalanceException;
import com.db.awmd.challenge.exception.OverDraftNotSupportedException;

import lombok.extern.slf4j.Slf4j;

// this implementation is visible to entire application It is not restricted to controller level.
// It is called as global exception handler 
@ControllerAdvice
@Slf4j
public class AccountServiceExceptionHandlingAspect extends ResponseEntityExceptionHandler {
	private static final Logger log = LoggerFactory.getLogger(AccountServiceExceptionHandlingAspect.class);

	@ExceptionHandler({ OverDraftNotSupportedException.class })
	public ResponseEntity<String> handleOverDaftNotSupportedException(OverDraftNotSupportedException ovdnse) {
		return error(HttpStatus.BAD_REQUEST, ovdnse);
	}

	@ExceptionHandler({ DuplicateAccountIdException.class })
	public ResponseEntity<String> handleDuplicateAccountIdException(DuplicateAccountIdException daide) {
		return error(HttpStatus.BAD_REQUEST, daide);
	}

	@ExceptionHandler({ NegativeBalanceException.class })
	public ResponseEntity<String> handleNegativeBalanceException(NegativeBalanceException nbe) {
		return error(HttpStatus.BAD_REQUEST, nbe);
	}

	@ExceptionHandler({ AccountNotFoundException.class, NullPointerException.class })
	public ResponseEntity<String> handleAccountNotFoundException(AccountNotFoundException anfe) {
		return error(HttpStatus.NOT_FOUND, anfe);
	}

	@ExceptionHandler({ AccountNotDeletedException.class })
	public ResponseEntity<String> handleAccountNotDeletedException(AccountNotDeletedException ande) {
		return error(HttpStatus.BAD_REQUEST, ande);
	}

	// method of ResponseEntityExceptionHandler class for displaying proper
	// validation message
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		// return handleExceptionInternal(ex, "Validation Exception", headers, status,
		// request);
		return new ResponseEntity<Object>("Bean Validation Failed", HttpStatus.BAD_REQUEST);
	}

	private ResponseEntity<String> error(HttpStatus status, Exception e) {
		log.error("Exception : {}", e.getMessage());
		return ResponseEntity.status(status).body(e.getMessage());
	}

}
