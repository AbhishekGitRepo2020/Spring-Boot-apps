package com.db.awmd.challenge.domain;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Entity
@Table(name = "ACCOUNT")
@Data
@ApiModel(description = "All details about the Account") // for Swagger Api documentation
//static filtering
@JsonIgnoreProperties({ "account_type" }) // for ommitting the bean properties in json response

//Dynamic filtering
//@JsonFilter("AccountFilter") 
//commented sine get request is failing but Dynamic filtering working as expected pfc in controller.
public class Account {

	@Id
	@Column(name = "account_Id")
	@NotNull
	@NotEmpty
	@ApiModelProperty(notes = "AccountId can be alphanumeric.")
	private final String accountId;

	@Column(name = "account_type")
	private String account_type;

	@Column(name = "account_balance")
	@NotNull
	@Min(value = 0, message = "Initial balance must be positive.")
	@ApiModelProperty(notes = "Initial balance must be positive.")
	private BigDecimal balance;

	public Account(String accountId) {
		this.accountId = accountId;
		this.balance = BigDecimal.ZERO;
		this.setAccount_type("premium Account");
	}

	@JsonCreator
	public Account(@JsonProperty("accountId") String accountId, @JsonProperty("balance") BigDecimal balance,
			@JsonProperty("account_type") String account_type) {
		this.accountId = accountId;
		this.balance = balance;
		this.account_type = account_type;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public String getAccountId() {
		return accountId;
	}

	public String getAccount_type() {
		return account_type;
	}

	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
}
