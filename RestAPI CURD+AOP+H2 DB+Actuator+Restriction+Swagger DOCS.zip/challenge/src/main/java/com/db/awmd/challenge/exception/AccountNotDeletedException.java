package com.db.awmd.challenge.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class AccountNotDeletedException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public AccountNotDeletedException(String message) {
		super(message);
	}

}
