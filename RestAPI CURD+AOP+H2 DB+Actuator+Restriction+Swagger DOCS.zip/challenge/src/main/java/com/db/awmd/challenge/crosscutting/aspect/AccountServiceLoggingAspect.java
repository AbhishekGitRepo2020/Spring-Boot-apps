package com.db.awmd.challenge.crosscutting.aspect;

import java.math.BigDecimal;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.db.awmd.challenge.domain.Account;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Component
@Slf4j
public class AccountServiceLoggingAspect {
	private static final Logger log = LoggerFactory.getLogger(AccountServiceLoggingAspect.class);

	// implementing before advice for create account
	@Before(value = "execution(* com.db.awmd.challenge.service.AccountsService.*(..)) and args(account)")
	public void beforeAdvice(JoinPoint joinPoint, Account account) {
		log.info("Before method: {}", joinPoint.getSignature());
		log.info("Creating Account with Account Id - {} and Balance {}", account.getAccountId(), account.getBalance());
	}

	// implementing after returning advice for getting the notification about fund
	// transfer
	@After(value = "execution(* com.db.awmd.challenge.service.AccountsService.*(..)) and args(fromAccountId, toAccountId, amount)")
	public void afterAdvice(JoinPoint joinPoint, String fromAccountId, String toAccountId, BigDecimal amount) {
		log.info("After method:" + joinPoint.getSignature());
		log.info("Fund transfer of Rs {} /- completed from: {} to: {} ", amount, fromAccountId, toAccountId);
	}

	// implementing around advice for account update/ deposit fund
	@Around(value = "execution(* com.db.awmd.challenge.service.AccountsService.*(..)) and args(accountId, newAmount)")
	private void aroundAdvice(ProceedingJoinPoint jp, String accountId, BigDecimal newAmount) throws Throwable {
		log.info("The method aroundAdvice() before invokation of the method: {} ",
				jp.getSignature().getName() + " method");
		log.info("fund: {} added to account id: {}", newAmount, accountId);
		try {
			jp.proceed();
		} finally {
		}
		log.info("funds successfully credited to accuont: {}", accountId);
		log.info("The method aroundAdvice() after invokation of the method: {}",
				jp.getSignature().getName() + " method");
	}

	// implementing after returning advice for fetching the account details

	@AfterReturning(value = "execution(* com.db.awmd.challenge.service.AccountsService.*(..)) and args(accountId)", returning = "account")
	public void afterReturningAdvice(JoinPoint joinPoint, String accountId, Account account) {
		log.info("After Returing method:" + joinPoint.getSignature());
		log.info("fetched Account: {} ", account);
	}

	// implementing after throwing advice if any exception is thrown during entire
	// process
	@AfterThrowing(value = "execution(* com.db.awmd.challenge.service.AccountsService.*(..))", throwing = "ex")
	public void afterThrowingAdvice(JoinPoint joinPoint, Exception ex) {
		log.info("After Throwing exception in method: {}", joinPoint.getSignature());
		log.info("Exception: {}", ex.getMessage());
	}
}
