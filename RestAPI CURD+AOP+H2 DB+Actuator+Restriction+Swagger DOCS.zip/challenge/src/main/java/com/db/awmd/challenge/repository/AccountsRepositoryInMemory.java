package com.db.awmd.challenge.repository;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.exception.AccountNotDeletedException;
import com.db.awmd.challenge.exception.AccountNotFoundException;
import com.db.awmd.challenge.exception.DuplicateAccountIdException;
import com.db.awmd.challenge.exception.NegativeBalanceException;
import com.db.awmd.challenge.exception.OverDraftNotSupportedException;
import com.db.awmd.challenge.service.EmailNotificationService;

import lombok.Getter;

@Repository
public class AccountsRepositoryInMemory implements AccountsRepository {

	private final Map<String, Account> accounts = new ConcurrentHashMap<>();

	@Getter
	public EmailNotificationService notificationService;

	@Autowired
	public AccountsRepositoryInMemory(EmailNotificationService notificationService) {
		this.notificationService = notificationService;
	}

	@Override
	public void createAccount(Account account) throws DuplicateAccountIdException {
		Account previousAccount = accounts.putIfAbsent(account.getAccountId(), account);
		if (previousAccount != null) {
			throw new DuplicateAccountIdException("Account id " + account.getAccountId() + " already exists!");
		}
	}

	@Override
	public Account getAccount(String accountId) {
		Account act = accounts.get(accountId);
		if (act == null) {
			throw new AccountNotFoundException("Account: " + accountId + " not Exists.");
		}
		return act;
	}

	@Override
	public void clearAccounts() {
		accounts.clear();
	}

	@Override
	public void deleteAccount(String accountId) {
		Account act = accounts.remove(accountId);
		if (act != null) {
			throw new AccountNotDeletedException("Account: " + accountId + " not deleted");
		}
	}

	@Override
	public synchronized void amountTransfer(String fromAccountId, String toAccountId, BigDecimal amount) {
		Account fromAccount = getAccount(fromAccountId);
		Account toAccount = getAccount(toAccountId);
		if (fromAccount.getBalance().compareTo(BigDecimal.ZERO) > 0 && fromAccount.getBalance().compareTo(amount) >= 0
				&& amount.compareTo(BigDecimal.ZERO) >= 0) {
			// initiate transfer process
			MathContext mc = new MathContext(10);
			BigDecimal fromAccountFinalBalance = fromAccount.getBalance().subtract(amount, mc);
			BigDecimal toAccountFinalBalance = toAccount.getBalance().add(amount, mc);

			updateAccount(fromAccountId, fromAccountFinalBalance);
			updateAccount(toAccountId, toAccountFinalBalance);
			notificationService.notifyAboutTransfer(fromAccount, "Amount: " + amount
					+ " has been debited. \n Updated final balance is: " + fromAccount.getBalance());
			notificationService.notifyAboutTransfer(toAccount,
					"Amount: " + amount + " has been credited. \n Updated final balance is: " + toAccount.getBalance());

		} else {
			// throw overdraft not supported exception
			throw new OverDraftNotSupportedException("Overdraft is not supported!!!");
		}

	}

	@Override
	public synchronized void updateAccount(String accountId, BigDecimal newAmount) {
		if (newAmount.compareTo(BigDecimal.ZERO) >= 0 && null != accountId && !"".equals(accountId)) {
			Account updateAccount = getAccount(accountId);
			updateAccount.setBalance(newAmount);
			accounts.put(accountId, updateAccount);
		} else {
			// throw overdraft not supported exception
			throw new NegativeBalanceException("Account Balance cannot be negative!");
		}
	}

	@Override
	public synchronized ArrayList<Account> getAllAccounts() {
		ArrayList<Account> accountList;
		if (accounts.size() == 0) {
			return null;
		}
		accountList = new ArrayList<>();
		accounts.forEach((k, v) -> accountList.add(v));
		return accountList;
	}
}
