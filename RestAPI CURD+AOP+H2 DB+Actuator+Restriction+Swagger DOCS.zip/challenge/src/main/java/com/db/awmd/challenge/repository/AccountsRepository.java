package com.db.awmd.challenge.repository;

import java.math.BigDecimal;
import java.util.ArrayList;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.exception.DuplicateAccountIdException;
import com.db.awmd.challenge.exception.OverDraftNotSupportedException;

public interface AccountsRepository { // extends JpaRepository<Account, Integer> { //readymade curd operation
										// No need to write its impl class. can directly be used in service.

	void createAccount(Account account) throws DuplicateAccountIdException;

	Account getAccount(String accountId);

	ArrayList<Account> getAllAccounts();

	void deleteAccount(String accountId);

	void updateAccount(String accountId, BigDecimal newAmount) throws OverDraftNotSupportedException;

	void clearAccounts();

	void amountTransfer(String fromAccountId, String toAccountId, BigDecimal amount)
			throws OverDraftNotSupportedException;
}
