package com.db.awmd.challenge.web;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.service.AccountsService;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v1/accounts")
@Slf4j
public class AccountsController {

	private final AccountsService accountsService;
	private static final Logger log = LoggerFactory.getLogger(AccountsController.class);

	@Autowired
	public AccountsController(AccountsService accountsService) {
		this.accountsService = accountsService;
	}

	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> createAccount(@RequestBody @Valid Account account) {
		log.info("Creating account with Id {}", account.getAccountId());
		this.accountsService.createAccount(account);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@GetMapping(path = "/{accountId}")
	public Account getAccount(@PathVariable String accountId) {
		log.info("Retrieving account for id {}", accountId);
		return this.accountsService.getAccount(accountId);
	}

	@PutMapping(path = "/{accountId}")
	public ResponseEntity<Object> updateAccount(@PathVariable final String accountId,
			@RequestParam("amount") @Valid String amount) {
		log.info("Adding funds to account: " + accountId + " with Amount: " + amount);
		MathContext mc = new MathContext(10);
		BigDecimal finalAmount = this.accountsService.getAccount(accountId).getBalance().add(new BigDecimal(amount),
				mc);
		this.accountsService.updateAccount(accountId, finalAmount);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@RequestMapping("/fundTransfer")
	public ResponseEntity<Object> fundTransfer(@RequestParam("fromAccountId") @Valid String fromAccountId,
			@RequestParam("toAccountId") @Valid String toAccountId, @RequestParam("amount") @Valid String amount) {
		log.info("Initated fund Transfer: " + amount + " from: " + fromAccountId + " To: " + toAccountId);
		this.accountsService.amountTransfer(fromAccountId, toAccountId, new BigDecimal(amount));
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@DeleteMapping(path = "/delete/{accountId}")
	public ResponseEntity<Object> deleteAccount(@PathVariable final String accountId) {
		log.info("Account: {} is going to be deleted", accountId);
		this.accountsService.deleteAccount(accountId);
		log.info("Account: {} is deleted", accountId);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	// Dynamic filtering demo
	@RequestMapping("/filtering/{accountId}")
	public MappingJacksonValue retrieveAccountDetailsFilter(@PathVariable String accountId) {
		log.info("Retrieving account for id {}", accountId);
		Account account = this.accountsService.getAccount(accountId);
		// invoking static method filterOutAllExcept()
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("accountId");
		// creating filter using FilterProvider class
		FilterProvider filters = new SimpleFilterProvider().addFilter("AccountFilter", filter);
		// constructor of MappingJacksonValue class that has bean as constructor
		// argument
		MappingJacksonValue mapping = new MappingJacksonValue(account);
		// configuring filters
		mapping.setFilters(filters);
		return mapping;
	}

	// Dynamic filtering list demo
	@RequestMapping("/filtering-list")
	public MappingJacksonValue retrieveAllAccountDetailsFilter() {
		log.info("Retrieving All Account Details");
		ArrayList<Account> accountList = this.accountsService.getAllAcoounts();
		// invoking static method filterOutAllExcept()
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("balance", "account_type");
		// creating filter using FilterProvider class
		FilterProvider filters = new SimpleFilterProvider().addFilter("AccountFilter", filter);
		// constructor of MappingJacksonValue class that has bean as constructor
		// argument
		MappingJacksonValue mapping = new MappingJacksonValue(accountList);
		// configuring filters
		mapping.setFilters(filters);
		return mapping;
	}

	// below implementation is used when we want to handle exception to controller
	// level.
	// this implementation is restricted to controller in which it implemented not
	// visible to other controller.

	/*
	 * @ExceptionHandler({ OverDraftNotSupportedException.class }) public
	 * ResponseEntity<String>
	 * handleOverDaftNotSupportedException(OverDraftNotSupportedException ovdnse) {
	 * return error(HttpStatus.BAD_REQUEST, ovdnse); }
	 * 
	 * private ResponseEntity<String> error(HttpStatus status, Exception e) {
	 * log.error("Exception : {} ", e.getMessage()); return
	 * ResponseEntity.status(status).body(e.getMessage()); }
	 */
}
