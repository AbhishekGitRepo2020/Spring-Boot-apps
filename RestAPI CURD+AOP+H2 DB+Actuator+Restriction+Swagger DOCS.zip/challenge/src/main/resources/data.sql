insert into ACCOUNT values('C1001', 'Premium Account', 3000);  
insert into ACCOUNT values('D1001', 'Ordinary Account', 2300);  
commit;